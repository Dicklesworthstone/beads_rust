#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static void *reader(void *argument) {
    int descriptor = *(int *)argument;
    char buffer[32];
    for (int i = 0; i < 10; i++) assert(pread(descriptor, buffer, sizeof(buffer), 0) == 32);
    return NULL;
}

int main(int argc, char **argv) {
    assert(argc == 3);
    char path[4096];
    assert(snprintf(path, sizeof(path), "%s/beads.db-wal", argv[1]) < (int)sizeof(path));
    if (strcmp(argv[2], "failed") == 0) {
        int descriptor = open(path, O_WRONLY);
        char buffer[32];
        assert(descriptor >= 0);
        errno = 0;
        assert(pread(descriptor, buffer, sizeof(buffer), 0) == -1);
        assert(errno == EBADF);
        close(descriptor);
        return 0;
    }
    int descriptor = open(path, O_CREAT | O_EXCL | O_RDWR, 0600);
    assert(descriptor >= 0);
    char bytes[8192] = {0};
    assert(write(descriptor, bytes, sizeof(bytes)) == sizeof(bytes));
    assert(pread(descriptor, bytes, 4120, 32) == 4120);
    assert(pread64(descriptor, bytes, 24, 32) == 24);
    pthread_t threads[4];
    for (int i = 0; i < 4; i++) assert(pthread_create(&threads[i], NULL, reader, &descriptor) == 0);
    for (int i = 0; i < 4; i++) assert(pthread_join(threads[i], NULL) == 0);
    close(descriptor);
    assert(snprintf(path, sizeof(path), "%s/beads.db-wal-cert", argv[1]) < (int)sizeof(path));
    descriptor = open(path, O_CREAT | O_EXCL | O_RDWR, 0600);
    assert(descriptor >= 0);
    assert(write(descriptor, bytes, 128) == 128);
    assert(pread(descriptor, bytes, 128, 0) == 128);
    close(descriptor);
    return 0;
}
