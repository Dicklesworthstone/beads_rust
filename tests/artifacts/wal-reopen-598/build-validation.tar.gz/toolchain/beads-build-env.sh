# Matched source build profile for Beads WAL #598 baseline/candidate validation.
# The distributed release uses different size/LTO settings; report that distinction.
source /workspace/scratch/e1a71523531b/toolchain/env.sh
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_RELEASE_OPT_LEVEL=1
export CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_PROFILE_RELEASE_LTO=false
export CARGO_PROFILE_RELEASE_CODEGEN_UNITS=256
export CARGO_PROFILE_RELEASE_INCREMENTAL=false
export CARGO_TARGET_DIR=/workspace/scratch/e1a71523531b/artifacts/target-beads
export RUSTFLAGS='-Zunstable-options --jobs-frontend=1 --jobs-backend=1 -Zfewer-names=yes -Ztime-passes=yes'
export MALLOC_CONF='abort_conf:true,narenas:1,dirty_decay_ms:0,muzzy_decay_ms:0,retain:false,tcache:false'
