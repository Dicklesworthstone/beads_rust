"""Run one matched Beads build and preserve source, resource, and binary receipts."""
from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/e1a71523531b')
label, repo_name, binary_name = sys.argv[1:4]
repo = root / repo_name
artifacts = root / 'artifacts'
prefix = artifacts / label
tracked = ['src/main.rs', 'src/cli/commands/doctor.rs', 'Cargo.toml', 'Cargo.lock',
           'rust-toolchain.toml', 'build.rs']

def hashes():
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest()
            for name in tracked}

before = hashes()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=repo)
with prefix.with_suffix('.patch').open('xb') as stream:
    stream.write(patch)
extra_cargo_arguments = sys.argv[4:]
command = ['cargo', *extra_cargo_arguments, 'build', '--locked', '--release', '--bin', 'br', '-j', '1']
build_configurations = {}
for index, argument in enumerate(extra_cargo_arguments[:-1]):
    if argument == '--config':
        config_path = Path(extra_cargo_arguments[index + 1])
        if config_path.is_file():
            content = config_path.read_bytes()
            build_configurations[str(config_path)] = {
                'sha256': hashlib.sha256(content).hexdigest(),
                'content': content.decode(),
            }
maximum_seconds = int(os.environ.get('WAL598_BUILD_TIMEOUT_SECONDS', '3600'))
started = time.monotonic()
minimum_free = shutil.disk_usage(root).free
stop_reason = None
log_path = prefix.with_suffix('.log')
with log_path.open('xb') as log:
    process = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    while process.poll() is None:
        time.sleep(1)
        free = shutil.disk_usage(root).free
        minimum_free = min(minimum_free, free)
        if free < 2 * 1024**3:
            stop_reason = 'Disk headroom fell below 2 GiB'
        elif time.monotonic() - started > maximum_seconds:
            stop_reason = f'Build exceeded {maximum_seconds} second time limit'
        if stop_reason:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            break
    returncode = process.wait()
after = hashes()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
receipt = {
    'command': command, 'repository': str(repo), 'source_commit': commit,
    'source_status_before': status, 'source_patch_sha256': hashlib.sha256(patch).hexdigest(),
    'source_hashes_before': before, 'source_hashes_after': after,
    'source_changed_during_build': before != after, 'returncode': returncode,
    'stop_reason': stop_reason, 'elapsed_seconds': time.monotonic() - started,
    'maximum_seconds': maximum_seconds, 'build_configurations': build_configurations,
    'max_rss_kib': usage.ru_maxrss, 'user_seconds': usage.ru_utime,
    'system_seconds': usage.ru_stime, 'minimum_free_disk_bytes': minimum_free,
    'overrides': {key: value for key, value in sorted(os.environ.items())
                  if key.startswith('CARGO_PROFILE_RELEASE_') or key in
                  ['CARGO_TARGET_DIR', 'CARGO_INCREMENTAL', 'CARGO_BUILD_JOBS',
                   'RUSTFLAGS', 'MALLOC_CONF']},
}
if returncode == 0 and before == after:
    source_binary = Path(os.environ['CARGO_TARGET_DIR']) / 'release/br'
    destination = artifacts / 'bin' / binary_name
    with source_binary.open('rb') as source, destination.open('xb') as target:
        shutil.copyfileobj(source, target)
    destination.chmod(0o755)
    receipt['binary_path'] = str(destination)
    receipt['binary_size_bytes'] = destination.stat().st_size
    receipt['binary_sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    receipt['binary_version'] = subprocess.check_output([str(destination), '--version'], text=True).strip()
with Path(str(prefix) + '-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2), flush=True)
sys.exit(3 if before != after else returncode)
