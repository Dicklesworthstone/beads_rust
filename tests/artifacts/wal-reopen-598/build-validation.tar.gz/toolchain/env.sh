export CARGO_HOME=/workspace/scratch/e1a71523531b/toolchain/cargo
export RUSTUP_HOME=/workspace/scratch/e1a71523531b/toolchain/rustup
export PATH=/workspace/scratch/e1a71523531b/toolchain/cargo/bin:$PATH
